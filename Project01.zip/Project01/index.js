const express = require('express')

const user = require('./MOCK_DATA.json')
const app = express();
const PORT = 8000;

//Routes
app.get("/api/user",(req , res)=>{
    return res.json(user);
})

app.get('/user' , (req , res) => {
    const html = `<ul>
        ${user.map(user => `<li>${user.first_name}</li>`).join("")}
    </ul>`

    res.send(html);
})




//Dynamic path
app.get('/api/user/:id' , (req , res)=> {
    const id = req.params.id;
    const user_id = user.find(user => user.id == id)
    return res.json(user_id);
})



app.listen(PORT , () => {
    console.log('server started at port ' + PORT);
})